-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: 04-Abr-2022 às 15:31
-- Versão do servidor: 5.7.23
-- versão do PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE vagabd;
USE vagabd;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vaga`
--

DROP TABLE IF EXISTS `vaga`;
CREATE TABLE IF NOT EXISTS `vaga` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `descricao` mediumtext NOT NULL,
  `ativo` enum('s','n') NOT NULL,
  `data`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `vaga`
--

INSERT INTO `vaga` (`id`, `titulo`, `descricao`, `ativo`, `data`) VALUES
(09, 'Programador', 'Saber PHP, HTML e CSS.', 'n', '2022-10-08 22:00:00'),
(10, 'Designer', 'Desenvolver a parte gráfica do sistema, etc...', 'n', '2022-10-18 23:00:00'),
(11, 'Técnico', 'Realizar manutenções em computadores, etc..', 's', '2022-10-04 00:00:00'),
(12, 'Investidor', 'Estar disposto a investir qualquer capital em prol do projeto.', 'n', '2022-10-22 01:00:00'),
(13, 'Scrum Master', 'Auxialiar os funcionários, "Coaching".', 's', '2022-09-28 02:00:00'),
(14, 'Analista', 'Desenvolver os requisitos do sistema, etc...', 's', '2022-11-04 03:00:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
