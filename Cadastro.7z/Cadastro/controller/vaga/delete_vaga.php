<?php
    include_once '../../model/Conexao.class.php';
    include_once '../../model/Entity.class.php';

    $vagaEntity = new Entity();
    $id = $_POST['id']; //pegando o id 

    if(isset($id) && !empty($id))
    {
        //chamar o método de delete do banco
        $vagaEntity->delete("vaga",$id);
        
        header("Location: ../../view/vaga/boardAdm.php");
    }

?>