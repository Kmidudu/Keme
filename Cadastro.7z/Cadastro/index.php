<?php
    include_once "./view/includes/header.php";
    include_once "./view/includes/board.php";
    include_once "./view/includes/footer.php";
?>