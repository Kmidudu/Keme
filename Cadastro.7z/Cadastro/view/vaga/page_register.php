<?php
    include_once 'header.php'

?>

<form action="../../controller/vaga/insert_vaga.php" method="POST">
    <div class="container">
        <div class="form text-light">
            <div class="form-group">
                Título:
            <input type="text" class="form-control" name="titulo" placeholder="Título" style="width:40%;" required autofocus />
            <br>
            </div>
            
            <div class="form-group">
                Descrição:
            <input type="text" class="form-control" name="descricao" placeholder="Descrição" required />
            <br>
            </div>
            <div class="form-group">
                Ativo:
                <div class="radio-item">
                 <input style="background-color: #323edb" type="radio" id="ativoA" name="ativo" value="s" checked>
                 <label for="ativoA">Sim</label>
                </div>

                <div class="radio-item">
                 <input style="background-color: #6a2cb1" type="radio" id="ativoB" name="ativo" value="n">
                 <label for="ativoB">Não</label>
                </div>
        </div>
        <div class="form-group">
                Data: 
                <input type="date" class="form-control" name="data" placeholder="Data de Disponibilidade" style="width:40%" required>
                 <br>
            </div>
        <div class="form-group">
            <button class="btn btn-outline-alt btn-lg">
                Adicionar
            </button>
        </div>
        </div>
    </div>
</form>

<?php
     include_once '../includes/footer.php'; 
?>
