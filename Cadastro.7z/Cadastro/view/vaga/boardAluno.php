<?php   
   include_once '../../model/Conexao.class.php';
   include_once '../../model/Entity.class.php';
   include_once 'headerAluno.php';

   $vagaEntity = new Entity();
?>

<div class="container mt-5">
  <!-- vagas -->
    
 <br> 
  <!-- container -->
</div>

<?php
     include_once '../includes/footer.php'; 
?>

